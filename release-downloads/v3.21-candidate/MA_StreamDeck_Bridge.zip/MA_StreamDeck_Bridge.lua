-- MA Stream Deck bridge 3.21 fix2: import as a Lua plugin and start once.
-- The Stream Deck plugin supplies/renews the temporary _G.MA322Bridge config.
-- No show objects or persistent user/global variables are modified.
-- cfg.lease is a renewal timestamp (os.time), valid for six seconds.
-- cfg.enabled=false pauses the bridge; a missing config also stays idle.
-- Stop the resident coroutine: Lua "_G.MA322Runner=nil".
-- Launching this plugin again replaces the previous runner at its next yield.
return function()
    local generation = math.max(tonumber(_G.MA322Runner) or 0,
        tonumber(_G.MA322Generation) or 0) + 1
    _G.MA322Generation = generation
    _G.MA322Runner = generation
    local nextAttrs, nextEncoder, nextHeartbeat = 0, 0, 0
    local lastError, previousSignature = -math.huge, nil
    local function report(message, now)
        if now - lastError >= 5 then
            lastError = now
            ErrPrintf('MA Stream Deck bridge: '..tostring(message))
        end
    end
    local function invoke(key, sequence, now)
        local scripts = _G.MA321Transport
        local entry = scripts and scripts[key]
        if not entry or type(entry.f) ~= 'function' then return false end
        -- Match the upload transport's existing cache clock.
        entry.at = os.clock()
        local ok, message = pcall(entry.f, sequence)
        if not ok then report(message, now) end
        return ok
    end
    Printf('MA Stream Deck bridge started; awaiting Stream Deck connection.')
    while _G.MA322Runner == generation do
        local now = Time()
        local cfg = _G.MA322Bridge
        local owner = type(cfg) == 'table' and cfg.owner
        local lease = type(cfg) == 'table' and tonumber(cfg.lease)
        local line = type(cfg) == 'table' and tonumber(cfg.line)
        local active = type(cfg) == 'table' and cfg.enabled == true
            and type(owner) == 'string' and owner:match('^[%w]+$')
            and lease and os.time() - lease >= 0 and os.time() - lease <= 6
            and line and line >= 1 and line <= 9999 and line == math.floor(line)
        if active then
            local signature = owner..':'..tostring(cfg.encoderKey)..':'..
                tostring(cfg.attrsKey)..':'..tostring(line)
            if signature ~= previousSignature then
                previousSignature = signature
                nextAttrs, nextEncoder, nextHeartbeat = now, now, now
            end
            -- At most one sample of each kind per tick, even after a slow frame.
            -- Never replay missed ticks or create a backlog in MA's command line.
            if now + 0.000001 >= nextEncoder then
                cfg.seq = (tonumber(cfg.seq) or 0) + 1
                invoke(cfg.encoderKey, cfg.seq, now)
                nextEncoder = now + 0.1
            end
            if now + 0.000001 >= nextAttrs then
                invoke(cfg.attrsKey, nil, now)
                nextAttrs = now + 0.05
            end
            if now + 0.000001 >= nextHeartbeat then
                local ok, message = pcall(function()
                    local q = string.char(34)
                    local scripts = _G.MA321Transport or {}
                    local encoder = scripts[cfg.encoderKey]
                    local attrs = scripts[cfg.attrsKey]
                    local encoderReady = encoder and type(encoder.f) == 'function'
                    local attrsReady = cfg.attrsKey == '' or
                        (attrs and type(attrs.f) == 'function')
                    local ready = (encoderReady and '1' or '0')..'~'..
                        (attrsReady and '1' or '0')
                    Cmd('SendOSC '..line..' '..q..'/deck/v322/'..
                        owner..'/live,s,'..ready..q)
                end)
                if not ok then report(message, now) end
                nextHeartbeat = now + 1
            end
        end
        coroutine.yield(0.05)
    end
end
