# GrandMA3 Deck 3.21 — versione candidata


Questa versione è stata verificata con test automatici del runtime, del Lua generato e del trasporto OSC. Non è stata eseguita su macOS con grandMA3 2.5.1.1 o su Stream Deck fisico: non considerare ancora conclusa la verifica di tutti i bug.

## Correzioni e limiti della sincronizzazione

Con **Bank source = From show / patch** e **Follow feature group = attivo**, il plugin interroga MA ogni 350 ms tramite la linea OSC di feedback. Legge `SelectedFeature()`, `GetSelectedAttribute()` e i canali dei fixture nella selezione corrente. Le pagine sono raggruppate per feature, in blocchi di quattro: su sei manopole gli slot in più restano vuoti. I nomi vengono dagli attributi MA, non da un elenco fisso di fixture di tutto lo show. Il tasto della bank attiva mostra il contatore di queste pagine.

Il cambio bank/pagina dal Deck invia la richiesta a MA e attende il feedback prima di cambiare l'assegnazione delle manopole. Durante l'attesa non modifica l'attributo della vecchia pagina. Il cambio della feature/attributo su MA aggiorna il Deck senza reinviare comandi in circolo. Se il feedback manca per due secondi, le manopole automatiche si svuotano e mostrano `In attesa MA`, poi riprendono al ritorno del feedback. Le bank personalizzate JSON e la modalità built-in conservano il controllo manuale.

**Limite aperto:** la pagina è ricostruita dalla feature e dall'attributo selezionati. Non è documentata un'API pubblica per il numero di pagina, lo scroll o l'ordine arbitrario di una finestra encoder. Se MA cambia solo pagina senza cambiare feature/attributo, la ricostruzione può non rilevarlo. Anche il comando di selezione attributo senza valore richiede conferma sul sistema MA reale. Per completare la corrispondenza esatta serve la diagnostica descritta sotto.

I range fisici vengono dal Channel Function del fixture e il formato dal `NaturalReadout` dell'attributo. I test verificano esempi Pan −270…+270 e Tilt −105…+105, senza codificare questi limiti nel plugin. Una preferenza Percent/Physical forzata soltanto nella finestra MA non è ancora letta. Il valore è quello del programmer attivo; output e default senza valore attivo non sono stati aggiunti. Per selezioni con fixture diversi, il valore/range rappresenta l'ultimo fixture della selezione, come il readback originale.

## Store e altri tasti

I 94 preset originali sono conservati e confrontati nei test. Store, Update, Delete, Copy e Assign preparano il comando nella riga locale del plugin; si completano con un Pool Object/Executor del plugin o con numeri/oggetto e Please. Per esempio: **Store → Sequence → 1 → Please**. Store ora resta evidenziato mentre il comando è in attesa. Il tasto Command Line mostra il testo preparato.

Premere Store sul Deck e poi toccare un oggetto direttamente sulla schermata MA non completa questo buffer. Anche il plugin originale allegato funziona in questo modo: non è stata trovata una regressione nel relativo trasporto. I test OSC confermano l'invio del comando completo, non l'esecuzione su una console MA reale.

## Diagnostica necessaria per le pagine esatte

1. Crea un plugin Lua temporaneo in MA e inserisci il contenuto di `diagnostics/inspect-encoder.lua` (incluso il `return function() ... end`).
2. Seleziona i fixture, apri una pagina degli Attributes e avvia il plugin diagnostico.
3. Copia dalla Command Line History le righe `[MA321]`.
4. Cambia **solo la pagina** degli Attributes su MA e ripeti. Invia le due letture insieme al nome della feature e al numero di parametri visibili.

La diagnostica legge soltanto gli oggetti e stampa proprietà limitate della barra encoder. Queste letture servono a verificare la pagina effettiva esposta da MA 2.5.1.1 e a completare l'adattatore senza indovinare nomi di proprietà interne.

## Aggiornamento

1. Esporta un backup del profilo attuale da Stream Deck.
2. Apri `GrandMA3_v3_21.streamDeckPlugin` e accetta l'aggiornamento del plugin.
3. Apri `GrandMA3_v3_21.streamDeckProfile` per importare il profilo aggiornato.
4. Se Stream Deck mantiene il vecchio processo del plugin, chiudi e riapri l'applicazione.
5. Nelle impostazioni di un'azione controlla IP MA3, porta OSC, prefisso, porta di feedback e numero della linea di feedback. Le impostazioni di connessione sono globali e non viaggiano necessariamente con il profilo esportato.

L'identificativo del plugin resta `com.michelecagnoni.gma3-deck-v37`: è intenzionale e mantiene funzionanti i pulsanti del profilo 3.16. La versione visibile e la versione del manifest sono 3.21. Non serve disinstallare il plugin precedente prima dell'aggiornamento.

Il manifest richiede Stream Deck 7.1 o successivo, macOS 13 o Windows 10, con il runtime Node 24 gestito da Stream Deck. Il profilo allegato proviene dal dispositivo `20GBX9901` e contiene sei controlli Encoder. Un dispositivo differente può richiedere l'adattamento del layout da parte di Stream Deck.

## Collegamento OSC

Usa i valori già funzionanti della tua installazione. I valori predefiniti del plugin sono:

| Impostazione | Valore predefinito |
| --- | --- |
| IP MA3 | `127.0.0.1` (MA3 onPC sullo stesso computer) |
| Porta comandi | `8000` |
| Prefisso | `gma3` |
| Porta feedback | `8001` |
| Numero linea feedback MA3 | `2` |

In grandMA3, Menu → In & Out → OSC:

- Abilita Enable Input ed Enable Output.
- Sulla linea che riceve i comandi abilita Receive e Receive Command; porta e prefisso devono corrispondere a quelli del plugin.
- Sulla linea di feedback imposta l'IP del computer Stream Deck e la porta di feedback; abilita Send e Send Command. Il numero di questa linea deve corrispondere a Feedback line nel plugin.
- Dal Property Inspector usa Send test command e Sync names now per verificare il percorso nei due sensi.

Il feedback utilizza comandi Lua trasmessi a MA3 tramite OSC. La lettura e la sincronizzazione dipendono dal fatto che MA3 accetti questi comandi e possa inviare le risposte al computer Stream Deck. Il solo aumento del contatore TX non conferma che il feedback funzioni.

## Profilo incluso

Il profilo ora si apre sulla pagina `grandMA3 Programmer`, invece della pagina predefinita vuota dell’allegato. Questa pagina usa i tasti Dimmer, Position, Gobo, Color, Beam, Focus e Shapers e gli encoder in modalità bank. La pagina Color Picker conserva invece gli encoder fissati a Red, Green, Blue, White, Hue e Saturation.

Il profilo contiene anche pagine e azioni di altri plugin: `com.addondesk.grandma3`, Clocks, Sho Metrics e azioni di sistema Stream Deck. Queste azioni sono state conservate; richiedono i rispettivi plugin già usati dal profilo originale. L'aggiornamento di GrandMA3 Deck non installa né modifica quei plugin.

## Verifica su MA3 e Stream Deck

I controlli automatici eseguibili in questo ambiente non sostituiscono una prova con il tuo show e la tua versione di MA3. Dopo l'importazione verifica:

1. Una selezione con solo Pan e Tilt e i suoi intervalli fisici effettivi.
2. Una selezione con attributi aggiuntivi e più pagine di encoder.
3. Il cambio di feature group e pagina prima da MA3 e poi da Stream Deck.
4. I valori agli estremi negativi e positivi, oltre alla posizione della barra.
5. Store, Update, Delete, Clear, numeri e Please, inclusa la selezione di un oggetto dopo Store.
6. Il cambio di selezione e di sessione, per verificare che non rimangano nomi o valori della selezione precedente.

## Sorgenti e pacchetti

Dalla cartella del progetto:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r tests/requirements.txt
MA3_TEST_PYTHON=.venv/bin/python bash scripts/test.sh
python3 scripts/package.py
```

Servono Python 3 e Node 24. Il comando controlla JSON, collegamenti tra azioni/profilo, versione e sintassi JavaScript; crea i due archivi in `dist/` e le rispettive impronte in `dist/SHA256SUMS`. Gli archivi mantengono la struttura degli allegati originali. La generazione del pacchetto non firma il plugin e non verifica l'importazione nell'applicazione Stream Deck.
