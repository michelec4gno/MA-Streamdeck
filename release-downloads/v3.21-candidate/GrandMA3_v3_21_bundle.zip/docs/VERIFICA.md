# Verifica della candidata 3.21

Eseguita in ambiente cloud Linux, Node 24.19.0, Python 3.12.14, Lupa 2.6.

Comando:

```sh
MA3_TEST_PYTHON=/workspace/.venvs/ma3-tests/bin/python bash scripts/test.sh
```

Risultati: **38 test JavaScript passati, 7 test Lua dei range passati, 7 test Lua della sincronizzazione passati**, nessun fallimento o test saltato. Validazione pacchetti: 21 azioni del plugin, 225 collegamenti del profilo; JSON e sintassi JavaScript validi. L'archivio conserva le licenze originali.

Verificati: i 94 preset dei tasti originali; Store con Preset, Executor e numeri/Please; codifica e ricezione di pacchetti OSC su socket UDP reali di localhost; selezione dei fixture, nomi e pagine ricostruite per feature; slot eccedenti vuoti su dispositivi a sei encoder; perdita/riordino dei pacchetti; aggiornamenti senza loop; ritorno del feedback dopo un'interruzione; cache separate per selezione/pagina; limiti fisici e unità per Pan/Tilt e altri attributi; modalità fisse e layer temporali.

**Non verificati:** installazione effettiva nell'app Stream Deck, esecuzione su grandMA3 2.5.1.1/macOS, Windows o console; semantica della selezione attributo senza valore sul sistema MA reale; corrispondenza con pagine/scroll/layout encoder arbitrari; readout forzato per singola finestra. Il feedback resta dei valori attivi del programmer, non dell'output/default. Store non prepara la riga MA per completarla toccando direttamente un oggetto sulla console.

La pagina effettiva non è esposta da un'API pubblica documentata nelle fonti MA 2.5 consultate. Per completare la verifica e l'eventuale adattatore UI servono due letture di `diagnostics/inspect-encoder.lua` prima/dopo un cambio di sola pagina sul sistema reale. Non considerare questa candidata una conferma che tutti i bug segnalati siano risolti.
