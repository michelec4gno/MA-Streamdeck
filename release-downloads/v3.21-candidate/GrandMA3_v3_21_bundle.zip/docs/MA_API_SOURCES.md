# Riferimenti API grandMA3

Le API usate sono state confrontate con la documentazione MA e con gli elenchi
`HelpLua` per grandMA3 2.5, conservati pubblicamente nel progetto
[ma3-lua-api-for-vscode](https://github.com/JeremyDufeux/ma3-lua-api-for-vscode/tree/main/ma_docs/2.5).
Revisione consultata: `b9c268c548367a1f81989520002cf4183346ff56` (22 ottobre 2026).
La documentazione verifica il contratto delle API; non sostituisce una prova su
grandMA3 2.5.1.1 e Stream Deck fisici.

- [`SelectedFeature()`](https://help.malighting.com/grandMA3/2.5/HTML/lua_objectfree_selectedfeature.html)
  restituisce il feature selezionato; il suo genitore identifica il feature group.
- [`GetSelectedAttribute()`](https://help.malighting.com/grandMA3/2.5/HTML/lua_objectfree_getselectedattribute.html)
  restituisce l'attributo selezionato. Non documenta la posizione della pagina
  encoder né garantisce che la selezione cambi a ogni scorrimento della barra.
- [`GetUIChannels()`](https://help.malighting.com/grandMA3/2.5/HTML/lua_objectfree_getuichannels.html)
  restituisce gli indici dei canali UI di una fixture selezionata; non descrive
  l'ordine dei controlli visibili sulla barra encoder.
- [`GetAttributeByUIChannel()`](https://help.malighting.com/grandMA3/2.5/HTML/lua_objectfree_getattributebyuichannel.html)
  restituisce il relativo attributo e permette di filtrare sulla selezione reale.
- [`GetChannelFunction(uiChannelIndex, attributeIndex)`](https://help.malighting.com/grandMA3/2.5/HTML/lua_objectfree_getchannelfunction.html)
  restituisce il channel function. Il secondo argomento è l'indice dell'attributo,
  **non** l'indice `channel_function` di un passo del phaser.
- [`CmdObj()`](https://help.malighting.com/grandMA3/2.5/HTML/lua_objectfree_cmdobj.html)
  espone il testo della command line in lettura. Le fonti consultate non
  documentano un metodo per simulare in sicurezza un tasto hardware Store.

I nomi delle proprietà `physicalFrom` e `physicalTo` sono presenti anche nelle
[definizioni pubbliche di ChannelFunction](https://github.com/LightYourWay/grandMA3-types/blob/main/typings/grandMA3.Patch/types/FixtureTypes.d.ts).
Le stesse definizioni descrivono `GetProgPhaserValue().absolute` come percentuale
normalizzata nel channel function: un Pan a 50% può dunque corrispondere a 0°.

## Limiti da verificare sulla macchina

Non è stata individuata un'API globale documentata per leggere la pagina esatta
della barra encoder. Raggruppare per feature, ordinare per indice e dividere a
quattro è una ricostruzione: non dimostra la corrispondenza esatta in presenza di
barre personalizzate, attributi secondari, filtri o pagine con diverso ordine.
Non attribuire queste garanzie ai soli test simulati.

`diagnostics/inspect-encoder.lua` legge un numero limitato di proprietà della
barra encoder senza cambiare lo show. Eseguirlo prima e dopo un cambio pagina
consente di verificare quali proprietà espone effettivamente la versione MA in
uso. Le righe `[MA321]` compaiono nella Command Line History.
