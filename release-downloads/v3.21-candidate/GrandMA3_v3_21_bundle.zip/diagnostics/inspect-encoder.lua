-- grandMA3 2.5: read-only encoder diagnostics.
-- Import as a temporary Lua plugin. Select a fixture, choose a feature/page,
-- run this plugin and copy the [MA321] lines from Command Line History.
-- Repeat after changing only the MA encoder page. No show data is changed.
return function()
    local count, seen = 0, {}
    local function log(s) Printf('[MA321] '..tostring(s)) end
    local function safe(fn)
        local ok, value = pcall(fn)
        if ok then return value end
        return nil
    end
    local function str(v)
        if v == nil then return '<nil>' end
        return (tostring(v):gsub('[%c]', ' ')):sub(1, 180)
    end
    local function object(h, path, depth)
        if not h or seen[h] or depth > 5 or count >= 120 then return end
        seen[h], count = true, count + 1
        log(path..' class='..str(safe(function() return h:GetClass() end))..
            ' name='..str(safe(function() return h.name end)))
        local n = safe(function() return h:PropertyCount() end) or 0
        for i = 1, math.min(n, 180) do
            local name = safe(function() return h:PropertyName(i) end)
            if name then
                local k = string.lower(tostring(name))
                if k:find('feature') or k:find('attribute') or k:find('page') or
                   k:find('layer') or k:find('readout') or k:find('encoder') or
                   k:find('selected') or k:find('index') or k == 'text' or
                   k == 'value' then
                    log(path..'.'..name..'='..str(safe(function() return h:Get(name) end)))
                end
            end
        end
        local children = safe(function() return h:Children() end) or {}
        for i, child in ipairs(children) do
            object(child, path..'/'..tostring(i), depth + 1)
        end
    end
    log('BEGIN version='..str(safe(function() return Version() end)))
    object(safe(function() return SelectedFeature() end), 'SelectedFeature', 4)
    object(safe(function() return GetSelectedAttribute() end), 'SelectedAttribute', 4)
    object(safe(function() return GetFocusDisplay().EncoderBarContainer end), 'EncoderBarContainer', 0)
    log('END nodes='..tostring(count)..' (limit 120)')
end
