# GrandMA3 Deck 3.21 — versione candidata

Plugin e profilo aggiornati a partire dai tre allegati dell'utente. Identificativo conservato: `com.michelecagnoni.gma3-deck-v37`.

- [Installazione e prova su MA3](docs/INSTALLAZIONE.md)
- [API MA 2.5 utilizzate e limiti](docs/MA_API_SOURCES.md)
- [Diagnostica della barra encoder](diagnostics/inspect-encoder.lua)

La sincronizzazione legge feature/attributo selezionati e gli attributi dei fixture selezionati. Ricostruisce pagine da quattro per feature; non dispone di un'API pubblica documentata per copiare qualsiasi layout/scroll della finestra encoder MA. La corrispondenza esatta delle pagine richiede ancora una verifica su grandMA3 2.5.1.1. Le API opzionali hanno controlli di disponibilità; Windows, console e versioni future non sono stati provati.

Pan/Tilt e altre unità fisiche usano i limiti dei Channel Function e il NaturalReadout dell'attributo, senza intervalli fissati per nome. Il feedback dei valori resta quello del programmer attivo, come negli allegati; non legge automaticamente output/default. Una preferenza di readout forzata nella singola finestra MA può differire.

Store conserva il funzionamento originale: buffer locale, poi oggetto/executor del plugin oppure Please. Ora il tasto evidenzia il comando in attesa. Store seguito da un oggetto toccato direttamente su MA non è supportato dal buffer locale, anche nell'originale allegato.

## Sviluppo e verifica

Node 24, Python 3 e Lupa 2.6 per eseguire il Lua generato nei test:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r tests/requirements.txt
MA3_TEST_PYTHON=.venv/bin/python bash scripts/test.sh
python3 scripts/package.py
```

La suite verifica il bundle JavaScript effettivo, i pacchetti UDP OSC su localhost e il Lua generato contro fixture di API MA. Le simulazioni non sostituiscono una prova con grandMA3 e Stream Deck reali. I pacchetti mantengono il formato ZIP dei file ricevuti e non sono firmati.
